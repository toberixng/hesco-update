<?php if(! defined('ABSPATH')){ return; }?>

<div class="skewmask-block" style="background-color:<?php echo esc_attr( $bgcolor ); ?>"></div>