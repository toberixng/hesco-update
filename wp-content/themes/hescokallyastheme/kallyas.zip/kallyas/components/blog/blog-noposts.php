<?php if(! defined('ABSPATH')){ return; } ?>
<div class="itemContainer noPosts kl-blog-item-container kl-blog-item--noposts">
    <p><?php echo __( 'Sorry, no posts matched your criteria.', 'zn_framework' ); ?></p>
</div><!-- end Blog Item -->
<div class="clear"></div>
